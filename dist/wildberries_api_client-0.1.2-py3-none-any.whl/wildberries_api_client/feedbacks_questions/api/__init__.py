from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from wildberries_api_client.feedbacks_questions.api.otzyvy_api import OtzyvyApi
from wildberries_api_client.feedbacks_questions.api.voprosy_api import VoprosyApi
from wildberries_api_client.feedbacks_questions.api.hablony_dla_voprosov_i_otzyvov_api import HablonyDlaVoprosovIOtzyvovApi
