from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from wildberries_api_client.prices.api.promokody_i_skidki_api import PromokodyISkidkiApi
from wildberries_api_client.prices.api.sostoania_zagruzok_api import SostoaniaZagruzokApi
from wildberries_api_client.prices.api.spiski_tovarov_api import SpiskiTovarovApi
from wildberries_api_client.prices.api.ustanovka_cen_i_skidok_api import UstanovkaCenISkidokApi
from wildberries_api_client.prices.api.ceny_api import CenyApi
