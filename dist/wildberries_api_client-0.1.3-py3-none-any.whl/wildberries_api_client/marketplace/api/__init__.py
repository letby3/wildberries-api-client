from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from wildberries_api_client.marketplace.api.ostatki_api import OstatkiApi
from wildberries_api_client.marketplace.api.postavki_api import PostavkiApi
from wildberries_api_client.marketplace.api.propuska_api import PropuskaApi
from wildberries_api_client.marketplace.api.sborohnye_zadania_api import SborohnyeZadaniaApi
from wildberries_api_client.marketplace.api.sklady_api import SkladyApi
