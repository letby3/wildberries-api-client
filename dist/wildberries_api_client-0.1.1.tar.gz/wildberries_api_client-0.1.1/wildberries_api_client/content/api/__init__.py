from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from wildberries_api_client.content.api._api import DefaultApi
from wildberries_api_client.content.api.analytics_api import AnalyticsApi
from wildberries_api_client.content.api.configurator_api import ConfiguratorApi
from wildberries_api_client.content.api.media_files_api import MediaFilesApi
from wildberries_api_client.content.api.tags_api import TagsApi
from wildberries_api_client.content.api.trash_api import TrashApi
from wildberries_api_client.content.api.upload_api import UploadApi
from wildberries_api_client.content.api.view_api import ViewApi
