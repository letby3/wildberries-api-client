from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from wildberries_api_client.prices.api.discounts_api import DiscountsApi
from wildberries_api_client.prices.api.price_and_discount_settings_api import PriceAndDiscountSettingsApi
from wildberries_api_client.prices.api.prices_api import PricesApi
from wildberries_api_client.prices.api.product_lists_api import ProductListsApi
from wildberries_api_client.prices.api.upload_states_api import UploadStatesApi
