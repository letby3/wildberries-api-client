from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from wildberries_api_client.marketplace.api.orders_api import OrdersApi
from wildberries_api_client.marketplace.api.passes_api import PassesApi
from wildberries_api_client.marketplace.api.stocks_api import StocksApi
from wildberries_api_client.marketplace.api.supplies_api import SuppliesApi
from wildberries_api_client.marketplace.api.warehouses_api import WarehousesApi
