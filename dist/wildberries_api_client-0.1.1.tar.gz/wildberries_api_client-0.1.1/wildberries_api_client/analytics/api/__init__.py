from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from wildberries_api_client.analytics.api.deductions_api import DeductionsApi
from wildberries_api_client.analytics.api.paid_storage_api import PaidStorageApi
from wildberries_api_client.analytics.api.products_with_mandatory_labeling_api import ProductsWithMandatoryLabelingApi
from wildberries_api_client.analytics.api.sales_funnel_api import SalesFunnelApi
