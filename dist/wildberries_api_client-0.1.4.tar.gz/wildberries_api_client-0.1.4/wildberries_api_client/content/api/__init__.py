from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from wildberries_api_client.content.api.konfigurator_api import KonfiguratorApi
from wildberries_api_client.content.api.korzina_api import KorzinaApi
from wildberries_api_client.content.api.mediafaily_api import MediafailyApi
from wildberries_api_client.content.api.prosmotr_api import ProsmotrApi
from wildberries_api_client.content.api.tegi_api import TegiApi
from wildberries_api_client.content.api.zagruzka_api import ZagruzkaApi
